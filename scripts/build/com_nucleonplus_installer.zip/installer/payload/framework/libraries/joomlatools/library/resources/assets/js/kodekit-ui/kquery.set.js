var globalCacheForjQueryReplacement = window.jQuery;
window.jQuery = window.kQuery;