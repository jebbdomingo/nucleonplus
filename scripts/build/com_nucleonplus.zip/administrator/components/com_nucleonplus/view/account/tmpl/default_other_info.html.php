<div class="panel panel-default">
    <div class="panel-heading">
        <h3 class="panel-title">
            Other Info.
        </h3>
    </div>
    <div class="panel-body">
        <?= $account->note ?>
    </div>
</div>