-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 31, 2016 at 02:37 AM
-- Server version: 5.5.46-0ubuntu0.14.04.2
-- PHP Version: 5.6.15-1+deb.sury.org~trusty+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sites_nucleonplus`
--

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_accounts`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_items`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_orders`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_packageitems`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_packages`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_payouts`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_rebates`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_referralbonuses`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_rewardpackages`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_rewards`;

-- --------------------------------------------------------

DROP TABLE IF EXISTS `#__nucleonplus_slots`;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
