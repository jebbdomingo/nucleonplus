<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_ConvUnit extends QuickBooks_IPP_Object
{
	
}
